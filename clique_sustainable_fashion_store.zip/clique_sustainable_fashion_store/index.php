<button
        type="button"
        class="btn btn-danger btn-floating btn-lg"
        id="btn-back-to-top"
        >
        <i class="fa fa-arrow-up"></i>
</button>

<?php
    include "head.html";
?>

    <div class="background">

        <div class="introtext">
            <div class="outer">Welcome to Clique</div> <br>
                <div class="inner"> 
                    <span>Where We carry the stories of the people to the people who value.</span>
                </div>
            </div>
        </div>

        <div class="slider">
            <div class="container">
                <div class="content">
                    <div class="slideshow">
                        <!-- carousel control buttons -->
                        <button class="slide-btn slide-btn-1"></button>
                        <button class="slide-btn slide-btn-2"></button>
                        <button class="slide-btn slide-btn-3"></button>
                        <!-- carousel wrapper which contains all images -->
                        <div class="slideshow-wrapper">
                            <div class="slide">
                                <img class="slide-img" src="clothing/slide/s1.png">
                            </div>
                            <div class="slide">
                                <img class="slide-img" src="clothing/slide/s2.jpg">
                            </div>
                            <div class="slide">
                                <img class="slide-img" src="clothing/slide/s3.png">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <br>

        <div class="titles"  id="brand-content">
            <div class="container-fixed">
                <div class="row">
                    <div class="col-lg">
                        <h1>
                            <img class="side" src="sitepics/side.png" id="side"> 
                            BRAND COLLABOATIONS
                            <img class="side" src="sitepics/side.png" id="side"> 
                        </h1>
                        
                    </div>
                </div>
            </div>
        </div>

        <br>

        <div class="brand-content">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6"> <!--1-->
                        <div class="view view-tenth">
                            <img src="clothing/brands/okhai.jpg" id="zoom">
                            <div class="mask">
                            <h2>OKHAI</h2>  
                                <p>Okhai has helped women like Laxmiben become monetarily independent while also helping them develop their individual skills. Life has definitely changed for women like Laxmiben who previously had not even seen a bank but now travel to Delhi and Bengaluru without any fear. Okhai conducts frequent training sessions for rural women, helping them understand fashion trends and colour patterns. Apart from this, they also visit exhibitions across India. "Earlier we use to work with only four colours but after joining Okhai I understand more about various shades of each colour and also about colour combinations. We frequently visit malls, designer showrooms to understand fashion, understand details about handicrafts and gain inspiration."</p>  
                                <a href="makeitvisible/showb4.php" class="info">BROWSE</a>
                            </div>
                        </div>  
                    </div>
                    <div class="col-lg-6"> <!--2-->
                        <div class="view view-tenth">
                            <img src="clothing/brands/nonasties.jpg" id="zoom">
                            <div class="mask">
                            <h2>NO NASTIES</h2>  
                                <p>Sustainability in fashion as well as other spheres has to be a consumer-led movement. And higher demand for organic cotton has to come from mindful consumers such as yourselves - we know YOU are because you're here ;) So, what do we do at No Nasties to grow the organic movement? We collaborate, NOT compete. Because we believe the organic movement in clothing is kinda something like a symphony. You can hum and strum all you want, but it's only an orchestra that'll make it come alive.</p>  
                                <a href="makeitvisible/showb3.php" class="info">BROWSE</a>
                            </div>
                        </div>   
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-6"> <!--3-->
                        <div class="view view-tenth">
                            <img src="clothing/brands/terratribe.jpg" id="zoom">
                            <div class="mask">
                            <h2>TERRA TRIBE</h2>  
                                <p>Timeless, minimal, chic, everyday clothing inspired by women all across the world made ethically. Terra is a latin word for earth, extending to oneness with nature. At The Terra Tribe we design contemporary clothing for people who are mindful of their impact on earth. 100% locally manufactured Tencel is used for the entire collection, made from responsibly sourced wood pulp using minimal non-renewable resources. 65% the energy needs of our fabric partner comes from renewable sources through their own wind mills. The water footprint for this fabric is only 5% compared to traditional cotton.</p>  
                                <a href="makeitvisible/showb8.php" class="info">BROWSE</a>
                            </div>
                        </div> 
                    </div>
                    <div class="col-lg-6"> <!--4-->
                    <div class="view view-tenth">
                            <img src="clothing/brands/sui.jpg" id="zoom">
                            <div class="mask">
                            <h2>SUI</h2>  
                                <p>SUI means needle in Hindi. We are a conscious fashion label based in India & Singapore. The needle for us represents connection, just as the needle connects the thread to a piece of fabric crafting it into a beautiful piece of clothing, our goal at SUI is to connect the threads of nature with fashion. How do we do this? By crafting clothing with a green heart. A green heart is one that respects nature and the people who craft our clothing.Our aim is to spread awareness on conscious fashion that is versatile, has a minimal impact, is relatable and treats its makers as family. We believe conscious fashion can be engaging, beautiful and impactful.</p>  
                                <a href="makeitvisible/showb7.php" class="info">BROWSE</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-6"> <!--5-->
                    <div class="view view-tenth">
                            <img src="clothing/brands/grassroot.jpg" id="zoom">
                            <div class="mask">
                            <h2>GRASSROOT</h2>  
                                <p>The Anita Dongre Foundation has given countless rural women a voice and a platform by providing them with livelihood opportunities and skill training. An ethical vegan, environmentalist and revivalist of local craft, Anita advocates compassionate living, which is why her designs do not use any fur or leather. She shares this worldview with her sister Meena Sehra and brother Mukesh Sawlani, who work alongside her. As a brand, our purpose lies in incorporating a lens of consciousness to all our business practices. Where each policy is continuously reviewed with the best in practice and adapted and improved upon to meet our own goals of energy consumption, carbon efficiency and repurposing resources. With each new update, we are taking strides towards our sustainability goals.</p>  
                                <a href="makeitvisible/showb1.php" class="info">BROWSE</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6"> <!--6-->
                    <div class="view view-tenth">
                            <img src="clothing/brands/oshadi.jpg" id="zoom">
                            <div class="mask">
                            <h2>OSHIDA</h2>  
                                <p>Ōshadi creates simple, functional, architectural designs rooted in a respectful relationship to the land and the local community. We are building a seed-to-sew supply chain with regenerative agricultural practices at its heart, based in a village in rural India. Our open-source system is designed to be shared. We create collections for like-minded brands looking to adopt transparent practices into their own business. Oshadi, pronounced aw-sha-dhi, means 'essence of nature' or 'healing plant' in Sanskrit. We began our journey as a womenswear label, founded by Nishanth Chopra in 2016. Our desire to respect and regenerate the Earth has since led us through every process that goes into creating clothing, from printing and dyeing to weaving and spinning, and eventually back to the soil.</p>  
                                <a href="makeitvisible/showb5.php" class="info">BROWSE</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-6"> <!--7-->
                    <div class="view view-tenth">
                            <img src="clothing/brands/nicobar.jpg" id="zoom">
                            <div class="mask">
                            <h2>NICOBAR</h2>  
                                <p>Sometimes things come together and dots just connect to make you take crazy leaps. I'm driven by creating environments to help people in their own journeys, whether as a parent or as a founder. We believed India is filled with design talent that has not scaled and we wanted to create a culture that nurtures creativity. Second, I loved the journey of Royal Enfield and Good Earth and learned so much from the Lals, the founding family of those companies, on thinking long term, doing things out of passion and building brands. We're a company that believes in culture as much as commerce, and that journeys are usually as worthy as destinations. These are the stories we're telling through our product and through a community. At Nicobar we are creating a modern Indian way of living, dressing, and looking at the world. This is at the heart of everything we do.</p>  
                                <a href="makeitvisible/showb2.php" class="info">BROWSE</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6"> <!--8-->
                    <div class="view view-tenth">
                            <img src="clothing/brands/pemmaraju.jpg" id="zoom">
                            <div class="mask">
                            <h2>PEMARAJU</h2>  
                                <p>We use time-honored techniques to create luxurious garments that honor the exceptional craftsmanship of India. By employing skilled artisans and paying them fairly for their craft, we create vibrant, one-of-a-kind clothing in a way that respects our planet and its people.Our collections are inspired by cultures around the world and designed in New York City before coming to life, stitch by stitch, at our private atelier in India. Each garment is consciously made for you: sewn by hand, adorned with love, and envisioned as a modern heirloom. We know you'll admire our artisans' gifts in every thoughtful detail, and hope our wearable treasures bring you inspiration and joy for a lifetime.</p>  
                                <a href="makeitvisible/showb6.php" class="info">BROWSE</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <br>

    </div>  

    

<?php
    include "footer.html";
?>