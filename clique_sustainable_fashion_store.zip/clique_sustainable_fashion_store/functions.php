<?php
    session_start();
    include 'db.php';

    function getall($table){
        global $con;
        $query = "select * from $table";
        return $query_run = mysqli_query($con,$query);
    }

    function getbyid($table,$id){
        global $con;
        $query = "select * from $table where id='$id'";
        return $query_run = mysqli_query($con,$query);

    }

    function getallactive($table){
        global $con;
        $query = "select * from $table where status";
        return $query_run = mysqli_query($con,$query);
    }

    function redirect($url,$message){
        header('location: '.$url);
        exit(0);
    }

?>

