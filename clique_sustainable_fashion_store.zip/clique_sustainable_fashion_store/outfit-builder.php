<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Outfit-Builder | CLIQUE</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Home | CLIQUE</title>
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="css/font-awesome.min.css" rel="stylesheet">
        <link href="css/outfit-builder.css" rel="stylesheet">
        <link href="css/animate.css" rel="stylesheet">

        <style>
            body{
                background-image: url("sitepics/home_background.png");
            }

            @font-face {
                font-family: 'newfont';
                src: url(fonts/Comfortaa-Bold.ttf);
            }
        </style>

        <script>
            var topcounter=0
            var bottomcounter=0
            var acccounter=0
            var shoecounter=0
            var tops=["outfit-builder/topwear/a (1).jpg","outfit-builder/topwear/a (2).jpg","outfit-builder/topwear/a (3).jpg","outfit-builder/topwear/a (4).jpg","outfit-builder/topwear/a (5).jpg","outfit-builder/topwear/a (6).jpg","outfit-builder/topwear/a (7).jpg","outfit-builder/topwear/a (7).jpg","outfit-builder/topwear/a (8).jpg","outfit-builder/topwear/a (9).jpg","outfit-builder/topwear/a (10).jpg","outfit-builder/topwear/a (11).jpg","outfit-builder/topwear/a (13).jpg","outfit-builder/topwear/a (14).jpg","outfit-builder/topwear/a (15).jpg"]
            var bottoms=["outfit-builder/bottomwear/a (1).jpg","outfit-builder/bottomwear/a (2).jpg","outfit-builder/bottomwear/a (3).jpg","outfit-builder/bottomwear/a (4).jpg","outfit-builder/bottomwear/a (5).jpg","outfit-builder/bottomwear/a (6).jpg","outfit-builder/bottomwear/a (7).jpg","outfit-builder/bottomwear/a (7).jpg","outfit-builder/bottomwear/a (8).jpg"]
            var accs=["outfit-builder/accessories/a (1).jpg","outfit-builder/accessories/a (2).jpg","outfit-builder/accessories/a (3).jpg","outfit-builder/accessories/a (4).jpg","outfit-builder/accessories/a (5).jpg","outfit-builder/accessories/a (6).jpg","outfit-builder/accessories/a (7).jpg","outfit-builder/accessories/a (7).jpg"]
            var shoes=["outfit-builder/shoes/a (1).jpg","outfit-builder/shoes/a (2).jpg","outfit-builder/shoes/a (3).jpg","outfit-builder/shoes/a (4).jpg","outfit-builder/shoes/a (5).jpg","outfit-builder/shoes/a (6).jpg","outfit-builder/shoes/a (7).jpg","outfit-builder/shoes/a (7).jpg"]
            lt=tops.length
            lb=bottoms.length
            la=accs.length
            ls=shoes.length

            function btn_next_top(){
                //next shirt on list
                document.getElementById("top").src=tops[topcounter]

                topcounter += 1
                if(topcounter==tops.length){
                    topcounter=0
                }
            }

            function btn_next_bottom(){
                //next shirt on list
                document.getElementById("bottom").src=bottoms[bottomcounter]

                bottomcounter += 1;
                if(bottomcounter==bottoms.length){
                    bottomcounter=0;
                }
            }

            function btn_next_acc(){
                //next shirt on list
                document.getElementById("acc").src=accs[acccounter]

                acccounter += 1;
                if(acccounter==accs.length){
                    acccounter=0;
                }
            }

            function btn_next_shoe(){
                //next shirt on list
                document.getElementById("shoe").src=shoes[shoecounter]

                shoecounter += 1;
                if(shoecounter==shoes.length){
                    shoecounter=0;
                }
            }

            function getRandomIntInclusive(min, max) {
                min = Math.ceil(min);
                max = Math.floor(max);
                return Math.floor(Math.random() * (max - min + 1) + min); // The maximum is inclusive and the minimum is inclusive
            }

            function randomize(){
                var randomtop = getRandomIntInclusive(0,lt-1);
                var randombottom = getRandomIntInclusive(0,lb-1);
                var randomacc = getRandomIntInclusive(0,la-1);
                var randomshoe = getRandomIntInclusive(0,ls-1);
                document.getElementById("top").src=tops[randomtop];
                document.getElementById("bottom").src=bottoms[randombottom];
                document.getElementById("acc").src=tops[randomacc];
                document.getElementById("shoe").src=tops[randomshoe];
            }

        </script>

    </head>

    <body>
        
        <div class="background">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-sm-4">
                        <a href="index.php">
                            <i class="fa fa-long-arrow-left"></i> 
                            <span class="ml-1">Back</span> 
				        </a></div>
                    <div class="col-sm-4 center">
                        <img src="sitepics/outfit-builder-logo.png">
                    </div>
                    <div class="col-sm-4"></div>
                </div>
                <br/><br/><br/>
                <div class="row">
                    <div class="col-md-3">
                        <div class="top">
                            <img src="outfit-builder/topwear/a (1).jpg" alt="" id="top">
                            <br/>
                            <button onClick="btn_next_top()">Topwear</button>
                        </div>  
                    </div>
                    <div class="col-md-3">
                        <div class="bottom">
                            <img src="outfit-builder/accessories/a (1).jpg" alt="" id="acc">
                            <br/>
                            <button onClick="btn_next_acc()">Accessories</button>
                        </div>
                    </div>   
                    <div class="col-md-3">
                        <div class="acc">
                            <img src="outfit-builder/bottomwear/a (1).jpg" alt="" id="bottom">
                            <br/>
                            <button onClick="btn_next_bottom()">Bottomwear</button>
                        </div> 
                    </div>
                    <div class="col-md-3">
                        <div class="shoe">
                            <img src="outfit-builder/shoes/a (1).jpg" alt="" id="shoe">
                            <br/>
                            <button onClick="btn_next_shoe()">Shoes</button>
                        </div>
                    </div>
                    </div>
                <br/><br/><br/>
                <div class="suprise center">
                    <button onClick="randomize()">Surprise Me!</button>
                </div>
                
            </div>
        </div> 
        
        
        
    </body>
</html>