<?php
		$id=$_GET["productid"];

		$con = mysqli_connect("localhost","root","","clique");
		$delete_query = mysqli_query($con,"delete insert_in_cart where pid = $id");
		if($insert_query){
            echo '<script>alert("Removed from cart Successfully!")</script>';
        }
        else{
            echo "fail";
        }
	?>