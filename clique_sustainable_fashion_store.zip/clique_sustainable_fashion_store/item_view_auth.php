<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Details | CLIQUE</title>
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/userprocess.css" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <script src="js/function.js"></script>

</head>

<body>
	<?php
		session_start();
		include "head3.html"
	?>

	<?php
		$id=$_GET["productid"];

		$con = mysqli_connect("localhost","root","","clique");
		$image_query = mysqli_query($con,"select * from store_img where pid = $id");
		while($row = mysqli_fetch_array($image_query)){
	?>

			<div class="container product-card">
				<div class="row ">
					<div class="col-lg-6">
						<div class="image pull_right">
							<img src="<?php echo $row["dir"];?>" alt=""/>
						</div>
					</div>
					<div class="col-lg-6">
						<div class="info">
							<div class="row">
								<div class="d-flex justify-content-between align-items-center">
									<div class="d-flex align-items-center"> 
										<a href="shop.php">
											<i class="fa fa-long-arrow-left"></i> 
											<span class="ml-1">Back</span> 
										</a>
										
									</div> 
								</div>
							</div>
							<br/><br/><br/>
							<div class="row">
								<h3><?php echo $row["brand"];?></h3>
								<h2><?php echo $row["product_name"];?></h2>
								<h3><?php echo $row["price"];?></h3>
								<p><?php echo $row["dsc"];?></p>
							</div>
							<br/>
							<div class="row">
								<div class="rate">
									<input type="radio" id="star5" name="rate" value="5" />
									<label for="star5" title="text">5 stars</label>
									<input type="radio" id="star4" name="rate" value="4" />
									<label for="star4" title="text">4 stars</label>
									<input type="radio" id="star3" name="rate" value="3" />
									<label for="star3" title="text">3 stars</label>
									<input type="radio" id="star2" name="rate" value="2" />
									<label for="star2" title="text">2 stars</label>
									<input type="radio" id="star1" name="rate" value="1" />
									<label for="star1" title="text">1 star</label>
								</div>
								<a href=""><h6 class="pull-right">Reviews</h6></a>
								<br/>
							</div>
							<br/><br/><br/><br/><br/><br/><br/>
							<div class="row">
								<div class="choose">
									<ul class="nav nav-pills nav-justified">
										<li><a href="insert-in-cart.php?productid=<?php echo $row['pid'];?>"><i class="fa fa-shopping-cart"></i>To Cart</a></li>
										<li><a href="cart.php?productid=<?php echo $row['pid'];?>"><i class="fa fa-sign-out"></i>Checkout</a></li>
									</ul>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>	

	<?php
		}
	?>

	<?php
		include "footer.html"
	?>

</body>
</html>