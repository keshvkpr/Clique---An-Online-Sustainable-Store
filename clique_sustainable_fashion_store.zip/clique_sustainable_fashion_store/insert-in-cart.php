<?php
		$id=$_GET["productid"];

		$con = mysqli_connect("localhost","root","","clique");
		$insert_query = mysqli_query($con,"insert insert_in_cart select * from store_img where pid = $id");
		if($insert_query){
            echo '<script>alert("Added to cart Successfully!")</script>';
        }
        else{
            echo '<script>alert("Already in the Cart!")</script>';
        }
	?>