<!DOCTYPE html>
<html lang="en">
	<head>

		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Payment | CLIQUE</title>
		<link href='https://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
		<link rel="stylesheet" href="css/payment.css" />

	</head>
	<body>

    <?php
        $id=$_GET["productid"];
		$con = mysqli_connect("localhost","root","","clique");
        $image_query = mysqli_query($con,"select * from store_img where pid = $id");
        while($row = mysqli_fetch_array($image_query)){
	?>

            <div class="container">
                <div class="card">
                    <a href="placed.php"><button class="proceed">
                        <svg class="sendicon" width="24" height="24" viewBox="0 0 24 24">
                            <path d="M4,11V13H16L10.5,18.5L11.92,19.92L19.84,12L11.92,4.08L10.5,5.5L16,11H4Z"></path>
                        </svg>
                    </button></a>
                    <img src="https://seeklogo.com/images/V/VISA-logo-62D5B26FE1-seeklogo.com.png" class="logo-card">
                    <label>Card number:</label>
                    <input id="user" type="text" class="input cardnumber"  placeholder="1234 5678 9101 1121">
                    <label>Name:</label>
                    <input class="input name"  placeholder="Edgar Pérez">
                    <label class="toleft">CCV:</label>
                    <input class="input toleft ccv" placeholder="321">
                </div>
                <br/><br/><br/>
                <div class="receipt">
                    <div class="col"><p>Cost:</p>
                    <h2 class="cost"><?php echo $row['price'];?></h2><br>
                    <p>Product info:</p>
                        <h2 class="cost"><?php echo $row['brand'];?></h2>
                        <h2 class="cost"><?php echo $row['product_name'];?></h2>
                    <div class="col">
                        
                    </div>
                    
                </div>
                <div class="col">
                    <img src="sitepics/clique_logo_short.png" width="300">
                    <br><br><br><br>
                </div>
                <p class="comprobe">This information will be sended to your email</p>
            </div>
        </div>

<?php
        }
?>

</body>
</html>	