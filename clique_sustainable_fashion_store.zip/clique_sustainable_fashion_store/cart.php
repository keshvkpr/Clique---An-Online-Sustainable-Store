<!DOCTYPE html>
<html>
<head>

<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta http-equiv="X-UA-Compatible" content="ie=edge">
		<title>Cart | CLIQUE</title>
		<link href="css/font-awesome.min.css" rel="stylesheet">
		<link href="css/animate.css" rel="stylesheet">
		<link href="css/cart.css" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">

<style>
	body{
                background-image: url('sitepics/home_background1.png');
                background-attachment: fixed;
                background-position: center;
            }
		
			@font-face {
                font-family: 'newfont';
                src: url(fonts/Comfortaa-Bold.ttf);
            }
</style>

</head>
<body>

	<main class="page">
	 	<section class="shopping-cart dark">
	 		<div class="container">
		        <div class="block-heading">
		          <h1>Shopping Cart</h1>
		        </div>
		        <div class="content center">
	 				<div class="row">

					<?php
						$con = mysqli_connect("localhost","root","","clique");
						$show_query = mysqli_query($con,"select * from insert_in_cart");
						$sum_query = mysqli_query($con,"select SUM(price) from insert_in_cart");
						while($row1 = mysqli_fetch_array($sum_query)){
							while($row = mysqli_fetch_array($show_query)){
					?>
					
							<div class="col-md-12">
								<div class="items">
									<div class="product">
										<div class="row">
											<div class="col-md-3">
												<img class="img-fluid mx-auto d-block image" src="<?php echo $row["dir"];?>">
											</div>
											<div class="col-md-8">
												<div class="info">
													<div class="row">
														<div class="col-md-5 product-name">
															<div class="product-name">
															<h5><?php echo $row["brand"];?></h5>
															<h2><?php echo $row["product_name"];?></h2>
															</div>
														</div>
														<div class="col-md-3 price">
															<h3><?php echo $row['price'];?></h3>
														</div>
													</div>
												</div>
											</div>
										</div>
						<?php
							
						}
						?>	
										<div class="row">
											<div class="col-sm-6"></div>
											<div class="col-sm-6"><h2>TOTAL = <?php echo $row1['SUM(price)'];?></h2></div>
										</div>
									</div>
								</div>
							</div>

						<?php
						}
						
						?>	
						
						</div>
					</div>
					<div class="row">
					<div class="col-sm-4"></div>
					<div class="col-sm-8 center"><a class="btn" href="paymentauth.php?productid=<?php echo $row1['pid'];?>">Checkout</a></div>
					</div>
		 			</div> 
		 		</div>
	 		</div>
		</section>
	</main>

</body>
</html>
