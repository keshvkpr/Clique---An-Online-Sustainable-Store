
        <?php
            include "head2.html";
        ?>

        <?php
        require('db.php');
        // If form submitted, insert values into the database.
        if (isset($_REQUEST['username'])){
            $username = stripslashes($_REQUEST['username']);
            $username = mysqli_real_escape_string($con,$username); 
            $email = stripslashes($_REQUEST['email']);
            $email = mysqli_real_escape_string($con,$email);
            $number = stripslashes($_REQUEST['number']);
            $number = mysqli_real_escape_string($con,$number);
            $password = stripslashes($_REQUEST['password']);
            $password = mysqli_real_escape_string($con,$password);
            $address = stripslashes($_REQUEST['address']);
            $date = date("Y-m-d H:i:s");

            $query = "INSERT into `users` (username, email, number,  password, address, date)
                    VALUES ('$username' , '$email' , '$number' , '".md5($password)."' , '$address' , '$date')";
            $result = mysqli_query($con,$query);

            if($result){
                    echo "<div class='form'>
                        <h3>You are registered successfully.</h3>
                        <br/>Click here to <a href='login.php'>Login</a></div>";
                }
                else{
                    echo "fail!";
                }
            }
            else{
        ?>

        <div class="reg">
            <div class="container">
                <div class="row">
                    <div class="col-sm-5">
                        <div class="showcase">

                        </div>
                    </div>
                    <div class="col-sm-7">
                        <div class="signup-form">
                            <form name="reg" action="" method="post">
                                <h2>New User Sign-Up</h2>
                                <input type="text"  name="username" placeholder="Username" required/>
                                <input type="email" name="email" placeholder="Email Address" required/>
                                <input type="text" placeholder="Mobile Number" name="number" required/>
                                <input type="password"  name="password" placeholder="Password" required/>
                                <input type="textarea" placeholder="Address" name="address" required/>
                                <button type="submit" class="btn btn-default">Signup</button>
                                <a href="login.php"><h5 class=" misctext1 pull-right"> Already a member? Click here to Login.</h5></a>
                             </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php } ?>

        <?php
            include "footer.html"
        ?>
