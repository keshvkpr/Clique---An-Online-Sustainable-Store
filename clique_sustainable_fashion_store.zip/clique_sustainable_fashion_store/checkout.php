<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Checkout | CLIQUE</title>
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/checkout.css" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <script src="js/function.js"></script>

    <style>
         @font-face {
                font-family: 'newfont';
                src: url(fonts/Comfortaa-Bold.ttf);
            }
    </style>

</head>

<body>

<?php
		$id=$_GET["productid"];

		$con = mysqli_connect("localhost","root","","clique");
		$image_query = mysqli_query($con,"select * from store_img where pid = $id");
		while($row = mysqli_fetch_array($image_query)){
	?>

            <div class="container">
                <form class="center" action="payment.php">
                    <div class="row">
                        <div class="col-md-6">
                            <h2>Billing Address</h2>
                            <label for="fname"><i class="fa fa-user"></i> Full Name</label>
                            <input type="text" id="fname" name="firstname" placeholder="First name">
                            <label for="email"><i class="fa fa-envelope"></i> Email</label>
                            <input type="text" id="email" name="email" placeholder="john@example.com">
                            <label for="adr"><i class="fa fa-address-card-o"></i> Address</label>
                            <input type="text" id="adr" name="address" placeholder="House number/Street/block">
                            <label for="city"><i class="fa fa-institution"></i> City</label>
                            <input type="text" id="city" name="city" placeholder="City">
                            <label for="state">State</label>
                            <input type="text" id="state" name="state" placeholder="State">
                            <label for="zip">Zip</label>
                            <input type="text" id="zip" name="zip" placeholder="10001">
                            <a class="btn center" href="payment.php?productid=<?php echo $row['pid'];?>">Continue to Checkout</a>
                        </div>
                    </div>
                </form>
            </div>

        <?php
		}
	?>

    </body>
</html>