-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 15, 2022 at 06:07 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `clique`
--
CREATE DATABASE IF NOT EXISTS `clique` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `clique`;

-- --------------------------------------------------------

--
-- Table structure for table `insert_in_cart`
--

CREATE TABLE `insert_in_cart` (
  `pid` int(10) NOT NULL,
  `brand` varchar(25) CHARACTER SET utf8 NOT NULL,
  `name` varchar(50) CHARACTER SET utf8 COLLATE utf8_estonian_ci NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `price` decimal(7,2) NOT NULL,
  `dsc` text NOT NULL,
  `dir` varchar(255) CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `insert_in_cart`
--

INSERT INTO `insert_in_cart` (`pid`, `brand`, `name`, `product_name`, `price`, `dsc`, `dir`) VALUES
(1, 'grassroot', '1', 'White kadhai suit', '3560.00', 'Handcrafted by local artisans and manufactured cautiously with the primary aim of producing sustainable products.\r\n\r\nMaterial used:\r\n -Cotton\r\n -kadhai', 'clothing/brands/grassroot/1.jpg'),
(2, 'grassroot', '2', 'Baby pink Suit', '5600.00', 'Handcrafted by local artisans and manufactured cautiously with the primary aim of producing sustainable products.\r\n\r\nMaterial used:\r\n -Cotton\r\n -kadhai', 'clothing/brands/grassroot/2.jpg'),
(64, 'terratribe', '8', 'Oversized Denim Shirt', '4599.00', 'Handcrafted by local artisans and manufactured cautiously with the primary aim of producing sustainable products.\r\n\r\nMaterial used:\r\n -Recycled Denim\r\n -Recycled plastic buttons', 'clothing/brands/terratribe/8.webp');

-- --------------------------------------------------------

--
-- Table structure for table `store_img`
--

CREATE TABLE `store_img` (
  `pid` int(10) NOT NULL,
  `brand` varchar(25) CHARACTER SET utf8 NOT NULL,
  `name` varchar(50) CHARACTER SET utf8 COLLATE utf8_estonian_ci NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `price` decimal(7,2) NOT NULL,
  `dsc` text NOT NULL,
  `dir` varchar(255) CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `store_img`
--

INSERT INTO `store_img` (`pid`, `brand`, `name`, `product_name`, `price`, `dsc`, `dir`) VALUES
(1, 'grassroot', '1', 'White kadhai suit', '3560.00', 'Handcrafted by local artisans and manufactured cautiously with the primary aim of producing sustainable products.\r\n\r\nMaterial used:\r\n -Cotton\r\n -kadhai', 'clothing/brands/grassroot/1.jpg'),
(2, 'grassroot', '2', 'Baby pink Suit', '5600.00', 'Handcrafted by local artisans and manufactured cautiously with the primary aim of producing sustainable products.\r\n\r\nMaterial used:\r\n -Cotton\r\n -kadhai', 'clothing/brands/grassroot/2.jpg'),
(3, 'grassroot', '3', 'Beige block print suit', '2550.00', 'Handcrafted by local artisans and manufactured cautiously with the primary aim of producing sustainable products.\r\n\r\nMaterial used:\r\n -Cotton\r\n -kadhai', 'clothing/brands/grassroot/3.jpg'),
(4, 'grassroot', '4', 'Yellow Kadhai suit', '3399.00', 'Handcrafted by local artisans and manufactured cautiously with the primary aim of producing sustainable products.\r\n\r\nMaterial used:\r\n -Cotton\r\n -kadhai', 'clothing/brands/grassroot/4.jpg'),
(5, 'grassroot', '5', 'Semi-silk Red suit', '2800.00', 'Handcrafted by local artisans and manufactured cautiously with the primary aim of producing sustainable products.\r\n\r\nMaterial used:\r\n -silk\r\n -kadhai', 'clothing/brands/grassroot/5.jpg'),
(6, 'grassroot', '6', 'Maroon kadhai Suit', '5800.00', 'Handcrafted by local artisans and manufactured cautiously with the primary aim of producing sustainable products.\r\n\r\nMaterial used:\r\n -Cotton\r\n -kadhai', 'clothing/brands/grassroot/6.jpg'),
(7, 'grassroot', '7', 'Hot-Red peplum Suit', '8650.00', 'Handcrafted by local artisans and manufactured cautiously with the primary aim of producing sustainable products.\r\n\r\nMaterial used:\r\n -Cotton\r\n -kadhai', 'clothing/brands/grassroot/7.jpg'),
(8, 'grassroot', '8', 'Red-Green Anaarkali Suit', '4599.00', 'Handcrafted by local artisans and manufactured cautiously with the primary aim of producing sustainable products.\r\n\r\nMaterial used:\r\n -Cotton\r\n -kadhai', 'clothing/brands/grassroot/8.jpg'),
(9, 'nicobar', '1', 'Blue Sweater ', '3560.00', 'Handcrafted by local artisans and manufactured cautiously with the primary aim of producing sustainable products.\r\n\r\nMaterial used:\r\n -Cotton\r\n -kadhai', 'clothing/brands/nicobar/1.webp'),
(10, 'nicobar', '2', 'Teddy bear pajamas', '5600.00', 'Handcrafted by local artisans and manufactured cautiously with the primary aim of producing sustainable products.\r\n\r\nMaterial used:\r\n -Cotton\r\n -kadhai', 'clothing/brands/nicobar/2.webp'),
(11, 'nicobar', '3', 'Yellow Sweater', '2550.00', 'Handcrafted by local artisans and manufactured cautiously with the primary aim of producing sustainable products.\r\n\r\nMaterial used:\r\n -Cotton\r\n -kadhai', 'clothing/brands/nicobar/3.webp'),
(12, 'nicobar', '4', 'Black dress', '3399.00', 'Handcrafted by local artisans and manufactured cautiously with the primary aim of producing sustainable products.\r\n\r\nMaterial used:\r\n -Cotton\r\n -kadhai', 'clothing/brands/nicobar/4.webp'),
(13, 'nicobar', '5', 'Polka dots Dress', '2800.00', 'Handcrafted by local artisans and manufactured cautiously with the primary aim of producing sustainable products.\r\n\r\nMaterial used:\r\n -Cotton\r\n -kadhai', 'clothing/brands/nicobar/5.webp'),
(14, 'nicobar', '6', 'Long Sweater', '5800.00', 'Handcrafted by local artisans and manufactured cautiously with the primary aim of producing sustainable products.\r\n\r\nMaterial used:\r\n -Cotton\r\n -kadhai', 'clothing/brands/nicobar/6.webp'),
(15, 'nicobar', '7', 'Dress-Sweater', '8650.00', 'Handcrafted by local artisans and manufactured cautiously with the primary aim of producing sustainable products.\r\n\r\nMaterial used:\r\n -Cotton\r\n -kadhai', 'clothing/brands/nicobar/7.webp'),
(16, 'nicobar', '8', 'Navy blue Dress', '4599.00', 'Handcrafted by local artisans and manufactured cautiously with the primary aim of producing sustainable products.\r\n\r\nMaterial used:\r\n -Cotton\r\n -kadhai', 'clothing/brands/nicobar/8.webp'),
(17, 'nonasties', '1', 'Black Dress', '3560.00', 'Handcrafted by local artisans and manufactured cautiously with the primary aim of producing sustainable products.\r\n\r\nMaterial used:\r\n -Cotton\r\n -Jute, Linen', 'clothing/brands/nonasties/1.webp'),
(18, 'nonasties', '2', 'Dark Green short-dress', '5600.00', 'Handcrafted by local artisans and manufactured cautiously with the primary aim of producing sustainable products.\r\n\r\nMaterial used:\r\n -Cotton\r\n -Jute, Linen', 'clothing/brands/nonasties/2.webp'),
(19, 'nonasties', '3', 'Blue not-so-common dress', '2550.00', 'Handcrafted by local artisans and manufactured cautiously with the primary aim of producing sustainable products.\r\n\r\nMaterial used:\r\n -Cotton\r\n -Jute, Linen', 'clothing/brands/nonasties/3.webp'),
(20, 'nonasties', '4', 'Beige pocket-dress', '3399.00', 'Handcrafted by local artisans and manufactured cautiously with the primary aim of producing sustainable products.\r\n\r\nMaterial used:\r\n -Cotton\r\n -Jute, Linen', 'clothing/brands/nonasties/4.webp'),
(21, 'nonasties', '5', 'Blue long Dress', '2800.00', 'Handcrafted by local artisans and manufactured cautiously with the primary aim of producing sustainable products.\r\n\r\nMaterial used:\r\n -Cotton\r\n -Jute, Linen', 'clothing/brands/nonasties/5.webp'),
(22, 'nonasties', '6', 'Sky blue long Dress', '5800.00', 'Handcrafted by local artisans and manufactured cautiously with the primary aim of producing sustainable products.\r\n\r\nMaterial used:\r\n -Cotton\r\n -Jute, Linen', 'clothing/brands/nonasties/6.webp'),
(23, 'nonasties', '7', 'Peach chic Dress', '8650.00', 'Handcrafted by local artisans and manufactured cautiously with the primary aim of producing sustainable products.\r\n\r\nMaterial used:\r\n -Cotton\r\n -Jute, Linen', 'clothing/brands/nonasties/7.webp'),
(24, 'nonasties', '8', 'Dark green Dress', '4599.00', 'Handcrafted by local artisans and manufactured cautiously with the primary aim of producing sustainable products.\r\n\r\nMaterial used:\r\n -Cotton\r\n -Jute, Linen', 'clothing/brands/nonasties/8.webp'),
(25, 'okhai', '1', 'Red and blue ethics', '3560.00', 'Handcrafted by local artisans and manufactured cautiously with the primary aim of producing sustainable products.\r\n\r\nMaterial used:\r\n -Cotton\r\n -Linen\r\n -Sequin using recycled plastic', 'clothing/brands/okhai/1.webp'),
(26, 'okhai', '2', 'Black semi-long skirt', '5600.00', 'Handcrafted by local artisans and manufactured cautiously with the primary aim of producing sustainable products.\r\n\r\nMaterial used:\r\n -Cotton\r\n -Linen\r\n -Sequin using recycled plastic', 'clothing/brands/okhai/2.webp'),
(27, 'okhai', '3', 'Hermes Oange Kurti', '2550.00', 'Handcrafted by local artisans and manufactured cautiously with the primary aim of producing sustainable products.\r\n\r\nMaterial used:\r\n -Cotton\r\n -Linen\r\n -Sequin using recycled plastic', 'clothing/brands/okhai/3.webp'),
(28, 'okhai', '4', 'Red Flowy Dress', '3399.00', 'Handcrafted by local artisans and manufactured cautiously with the primary aim of producing sustainable products.\r\n\r\nMaterial used:\r\n -Cotton\r\n -Linen\r\n -Sequin using recycled plastic', 'clothing/brands/okhai/4.webp'),
(29, 'okhai', '5', 'Mustard Suit set', '2800.00', 'Handcrafted by local artisans and manufactured cautiously with the primary aim of producing sustainable products.\r\n\r\nMaterial used:\r\n -Cotton\r\n -Linen\r\n -Sequin using recycled plastic', 'clothing/brands/okhai/5.webp'),
(30, 'okhai', '6', 'Short grey kurti', '5800.00', 'Handcrafted by local artisans and manufactured cautiously with the primary aim of producing sustainable products.\r\n\r\nMaterial used:\r\n -Cotton\r\n -Linen\r\n -Sequin using recycled plastic', 'clothing/brands/okhai/6.webp'),
(31, 'okhai', '7', 'Red Short Kurti', '8650.00', 'Handcrafted by local artisans and manufactured cautiously with the primary aim of producing sustainable products.\r\n\r\nMaterial used:\r\n -Cotton\r\n -Linen\r\n -Sequin using recycled plastic', 'clothing/brands/okhai/7.webp'),
(32, 'okhai', '8', 'Green Sequin Kurti', '4599.00', 'Handcrafted by local artisans and manufactured cautiously with the primary aim of producing sustainable products.\r\n\r\nMaterial used:\r\n -Cotton\r\n -Kadhai\r\n -Sequin using recycled plastic', 'clothing/brands/okhai/8.webp'),
(33, 'oshida', '1', 'Denim Overcoat', '3560.00', 'Handcrafted by local artisans and manufactured cautiously with the primary aim of producing sustainable products.\r\n\r\nMaterial used:\r\n -Cotton\r\n -Recycled Denim\r\n -Laces using recycled plastic', 'clothing/brands/oshida/1.webp'),
(34, 'oshida', '2', 'Deep Yellow Dress', '5600.00', 'Handcrafted by local artisans and manufactured cautiously with the primary aim of producing sustainable products.\r\n\r\nMaterial used:\r\n -Cotton\r\n -Laces using recycled plastic', 'clothing/brands/oshida/2.webp'),
(35, 'oshida', '3', 'Thunderstorm grey dress', '2550.00', 'Handcrafted by local artisans and manufactured cautiously with the primary aim of producing sustainable products.\r\n\r\nMaterial used:\r\n -Cotton\r\n -Laces using recycled plastic', 'clothing/brands/oshida/3.webp'),
(36, 'oshida', '4', 'Denim Short Coat', '3399.00', 'Handcrafted by local artisans and manufactured cautiously with the primary aim of producing sustainable products.\r\n\r\nMaterial used:\r\n -Cotton\r\n -Laces using recycled plastic', 'clothing/brands/oshida/4.webp'),
(37, 'oshida', '5', 'Pure white Dress', '2800.00', 'Handcrafted by local artisans and manufactured cautiously with the primary aim of producing sustainable products.\r\n\r\nMaterial used:\r\n -Cotton\r\n -Recycled Denim', 'clothing/brands/oshida/5.webp'),
(38, 'oshida', '6', 'Black & White Dress', '5800.00', 'Handcrafted by local artisans and manufactured cautiously with the primary aim of producing sustainable products.\r\n\r\nMaterial used:\r\n -Cotton\r\n -Recycled Denim\r\n -Laces using recycled plastic', 'clothing/brands/oshida/6.webp'),
(39, 'oshida', '7', 'Boho long Shirt', '8650.00', 'Handcrafted by local artisans and manufactured cautiously with the primary aim of producing sustainable products.\r\n\r\nMaterial used:\r\n -Cotton\r\n -Linen', 'clothing/brands/oshida/7.webp'),
(40, 'oshida', '8', 'Denim Dress set', '4599.00', 'Handcrafted by local artisans and manufactured cautiously with the primary aim of producing sustainable products.\r\n\r\nMaterial used:\r\n -Cotton\r\n -Recycled Denim\r\n -Laces using recycled plastic', 'clothing/brands/oshida/8.webp'),
(41, 'pemmaraju', '1', 'Dress 1', '3560.00', 'Handcrafted by local artisans and manufactured cautiously with the primary aim of producing sustainable products.\r\n\r\nMaterial used:\r\n -Cotton\r\n -Recycled Polyester', 'clothing/brands/pemmaraju/1.webp'),
(42, 'pemmaraju', '2', 'Dress 2', '5600.00', 'Handcrafted by local artisans and manufactured cautiously with the primary aim of producing sustainable products.\r\n\r\nMaterial used:\r\n -Cotton\r\n -Recycled Polyester', 'clothing/brands/pemmaraju/2.webp'),
(43, 'pemmaraju', '3', 'Dress 3', '2550.00', 'Handcrafted by local artisans and manufactured cautiously with the primary aim of producing sustainable products.\r\n\r\nMaterial used:\r\n -Cotton\r\n -Recycled Polyester', 'clothing/brands/pemmaraju/3.webp'),
(44, 'pemmaraju', '4', 'Dress 4', '3399.00', 'Handcrafted by local artisans and manufactured cautiously with the primary aim of producing sustainable products.\r\n\r\nMaterial used:\r\n -Cotton\r\n -Recycled Polyester', 'clothing/brands/pemmaraju/4.webp'),
(45, 'pemmaraju', '5', 'Dress 5', '2800.00', 'Handcrafted by local artisans and manufactured cautiously with the primary aim of producing sustainable products.\r\n\r\nMaterial used:\r\n -Cotton\r\n -Recycled Polyester', 'clothing/brands/pemmaraju/5.webp'),
(46, 'pemmaraju', '6', 'Dress 6', '5800.00', 'Handcrafted by local artisans and manufactured cautiously with the primary aim of producing sustainable products.\r\n\r\nMaterial used:\r\n -Cotton\r\n -Recycled Polyester', 'clothing/brands/pemmaraju/6.webp'),
(47, 'pemmaraju', '7', 'Dress 7', '8650.00', 'Handcrafted by local artisans and manufactured cautiously with the primary aim of producing sustainable products.\r\n\r\nMaterial used:\r\n -Cotton\r\n -Recycled Polyester', 'clothing/brands/pemmaraju/7.webp'),
(48, 'pemmaraju', '8', 'Dress 8', '4599.00', 'Handcrafted by local artisans and manufactured cautiously with the primary aim of producing sustainable products.\r\n\r\nMaterial used:\r\n -Cotton\r\n -Recycled Polyester', 'clothing/brands/pemmaraju/8.webp'),
(49, 'sui', '1', 'Chiffon Dress', '3560.00', 'Handcrafted by local artisans and manufactured cautiously with the primary aim of producing sustainable products.\r\n\r\nMaterial used:\r\n -Chiffon\r\n -Environment safe printing', 'clothing/brands/sui/1.webp'),
(50, 'sui', '2', 'Chiffon Dress', '5600.00', 'Handcrafted by local artisans and manufactured cautiously with the primary aim of producing sustainable products.\r\n\r\nMaterial used:\r\n -100% Cotton\r\n -Environment safe printing', 'clothing/brands/sui/2.webp'),
(51, 'sui', '3', 'Comfy wear', '2550.00', 'Handcrafted by local artisans and manufactured cautiously with the primary aim of producing sustainable products.\r\n\r\nMaterial used:\r\n -100% Cotton\r\n -Environment safe printing', 'clothing/brands/sui/3.webp'),
(52, 'sui', '4', 'Yellow belted Dress', '3399.00', 'Handcrafted by local artisans and manufactured cautiously with the primary aim of producing sustainable products.\r\n\r\nMaterial used:\r\n -100% Cotton\r\n -Environment safe printing', 'clothing/brands/sui/4.webp'),
(53, 'sui', '5', 'Leafy Dress', '2800.00', 'Handcrafted by local artisans and manufactured cautiously with the primary aim of producing sustainable products.\r\n\r\nMaterial used:\r\n -100% Cotton\r\n -Environment safe printing', 'clothing/brands/sui/5.webp'),
(54, 'sui', '6', 'Short Dress', '5800.00', 'Handcrafted by local artisans and manufactured cautiously with the primary aim of producing sustainable products.\r\n\r\nMaterial used:\r\n -100% Cotton\r\n -Environment safe printing', 'clothing/brands/sui/6.webp'),
(55, 'sui', '7', 'Starry Cupcake Dress', '8650.00', 'Handcrafted by local artisans and manufactured cautiously with the primary aim of producing sustainable products.\r\n\r\nMaterial used:\r\n -100% Cotton\r\n -Environment safe printing', 'clothing/brands/sui/7.webp'),
(56, 'sui', '8', 'Half-sleves Dress', '4599.00', 'Handcrafted by local artisans and manufactured cautiously with the primary aim of producing sustainable products.\r\n\r\nMaterial used:\r\n -100% Cotton\r\n -Environment safe printing', 'clothing/brands/sui/8.webp'),
(57, 'terratribe', '1', 'Short Dark Dress', '3560.00', 'Handcrafted by local artisans and manufactured cautiously with the primary aim of producing sustainable products.\r\n\r\nMaterial used:\r\n -100% Cotton\r\n -Environment safe printing', 'clothing/brands/terratribe/1.webp'),
(58, 'terratribe', '2', 'Polka-dots Overcoat', '5600.00', 'Handcrafted by local artisans and manufactured cautiously with the primary aim of producing sustainable products.\r\n\r\nMaterial used:\r\n -100% Cotton\r\n -Environment safe printing', 'clothing/brands/terratribe/2.webp'),
(59, 'terratribe', '3', 'Semi-formal Set', '2550.00', 'Handcrafted by local artisans and manufactured cautiously with the primary aim of producing sustainable products.\r\n\r\nMaterial used:\r\n -Recycled Denim\r\n -100% cotton', 'clothing/brands/terratribe/3.webp'),
(60, 'terratribe', '4', 'Night Comfy Wear', '3399.00', 'Handcrafted by local artisans and manufactured cautiously with the primary aim of producing sustainable products.\r\n\r\nMaterial used:\r\n -Recycled materials\r\n -Shiffon', 'clothing/brands/terratribe/4.webp'),
(61, 'terratribe', '5', 'Trousers', '2800.00', 'Handcrafted by local artisans and manufactured cautiously with the primary aim of producing sustainable products.\r\n\r\nMaterial used:\r\n -100% Cotton\r\n -Linen', 'clothing/brands/terratribe/5.webp'),
(62, 'terratribe', '6', 'Polka dots denim set', '5800.00', 'Handcrafted by local artisans and manufactured cautiously with the primary aim of producing sustainable products.\r\n\r\nMaterial used:\r\n -Recycled Denim\r\n -Recycled plastic buttons', 'clothing/brands/terratribe/6.webp'),
(63, 'terratribe', '7', 'White denim set', '8650.00', 'Handcrafted by local artisans and manufactured cautiously with the primary aim of producing sustainable products.\r\n\r\nMaterial used:\r\n -Recycled Denim\r\n -Recycled plastic buttons', 'clothing/brands/terratribe/7.webp'),
(64, 'terratribe', '8', 'Oversized Denim Shirt', '4599.00', 'Handcrafted by local artisans and manufactured cautiously with the primary aim of producing sustainable products.\r\n\r\nMaterial used:\r\n -Recycled Denim\r\n -Recycled plastic buttons', 'clothing/brands/terratribe/8.webp');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `number` varchar(11) NOT NULL,
  `password` varchar(50) NOT NULL,
  `address` varchar(200) NOT NULL,
  `date` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `number`, `password`, `address`, `date`) VALUES
(1, 'keshavkapoor', 'kapoor0241@gmail.com', '07527871204', '25d55ad283aa400af464c76d713c07ad', '107, New Punjab Mata Nagar, near vishal nagar, pakhowal road, ludhiana', '0000-00-00 00:00:00'),
(4, 'kk', 'Keshavkapoor49@gmail.com', '07527871204', '25d55ad283aa400af464c76d713c07ad', '107, New Punjab Mata Nagar, near vishal nagar, pakhowal road, ludhiana', '2022-10-30 21:00:40'),
(6, 'heh', 'heh@gmail.com', '1235678900', '52605a118d3123252d8ede57844b89e5', '107, New Punjab Mata Nagar, near vishal nagar, pakhowal road, ludhiana', '2022-10-30 21:46:11'),
(8, 'vivek', 'vk@cuchd.in', '07527871204', '25d55ad283aa400af464c76d713c07ad', '107, New Punjab Mata Nagar, near vishal nagar, pakhowal road, ludhiana', '2022-11-09 03:53:48');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `insert_in_cart`
--
ALTER TABLE `insert_in_cart`
  ADD PRIMARY KEY (`pid`);

--
-- Indexes for table `store_img`
--
ALTER TABLE `store_img`
  ADD PRIMARY KEY (`pid`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `insert_in_cart`
--
ALTER TABLE `insert_in_cart`
  MODIFY `pid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=65;

--
-- AUTO_INCREMENT for table `store_img`
--
ALTER TABLE `store_img`
  MODIFY `pid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=65;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
