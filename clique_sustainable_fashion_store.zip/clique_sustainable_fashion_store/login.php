        <?php
            include "head2.html";
        ?>

        <?php
        require('db.php');
        session_start();
        // If form submitted, insert values into the database.
        if (isset($_POST['username'])){
            $username = stripslashes($_REQUEST['username']);
            $username = mysqli_real_escape_string($con,$username);
            $password = stripslashes($_REQUEST['password']);
            $password = mysqli_real_escape_string($con,$password);
            //Checking is user existing in the database or not
            $query = "SELECT * FROM `users` WHERE username='$username'and password='".md5($password)."'";
            $result = mysqli_query($con,$query) or die(mysql_error());
            $rows = mysqli_num_rows($result);
                
            if($rows==1){
                $_SESSION['username'] = $username;
                header("Location: home.php");
                }
                else{
                    //echo(loginValidation());
                    echo "<div class='form'>
                        <h3>Username/password is incorrect.</h3>
                        <br/>Click here to <a href='login.php'>Login</a></div>";
            }
        }
        else{
        ?>

        <div class="reg">
            <div class="container">
                <div class="row">
                <div class="col-sm-5">
                        <div class="showcase">
                            
                        </div>
                    </div>
                    <div class="col-sm-7">
                        <div class="login-form">
                            <h2>Existing User</h2>
                            <form name="login" action="" method="post">
                                    <input type="text" placeholder="Name" name="username"/>
                                    <input type="password" placeholder="Password" name="password" />
                                    <button type="submit" class="btn btn-default" onclick="loginValidation()">Login</button>
                                    <a href="reg.php"><h5 class=" misctext1 pull-right"> New here? Click here to Sign-up.</h5></a>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php } ?>

        <?php
            include "footer.html"
        ?>

        <script src="js/function.js"></script>
    </body>
</html>