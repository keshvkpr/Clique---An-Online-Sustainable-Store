<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Home | CLIQUE</title>
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="css/font-awesome.min.css" rel="stylesheet">
        <link href="css/functions.css" rel="stylesheet">
        <link href="css/animate.css" rel="stylesheet">
        <script src="js/function.js"></script>

        <style>
            body{
                background-image: url('sitepics/home_background1.png');
                background-attachment: fixed;
                background-position: center;
            }

            @font-face {
                font-family: 'newfont';
                src: url(fonts/Comfortaa-Bold.ttf);
            }

            .center{
                display: flex;
                align-items: center;
                justify-content: center;
            }

        </style>

    </head>

    <body>

        <?php
            include "head.html";
        ?>

        <br/><br/><br/><br/><br/><br/><br/><br/><br/>

       <h1 class="center">YOUR ORDER HAVE BEEN PLACED!</h1>

    </body>
</html>