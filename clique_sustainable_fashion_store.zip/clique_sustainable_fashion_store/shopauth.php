<button
        type="button"
        class="btn btn-danger btn-floating btn-lg"
        id="btn-back-to-top"
        >
        <i class="fa fa-arrow-up"></i>
</button>

<?php
	session_start();
    include "head3.html";
?>

<?php 
	$con = mysqli_connect("localhost","root","","clique");
?>

<!DOCTYPE html>
<html lang="en">
	<head>

		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta http-equiv="X-UA-Compatible" content="ie=edge">
		<title>Shop | CLIQUE</title>
		<link href="css/font-awesome.min.css" rel="stylesheet">
		<link href="css/animate.css" rel="stylesheet">
		<link href="css/shop.css" rel="stylesheet">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
		<script src="js/function.js"></script>

		<script type="text/javascript">
			function rangeSlide(value) {
				document.getElementById('rangeValue').innerHTML = value;
			}

			// Get the button:
			let mybutton = document.getElementById("myBtn");

			// When the user scrolls down 20px from the top of the document, show the button
			window.onscroll = function() {scrollFunction()};

			function scrollFunction() {
				if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
					mybutton.style.display = "block";
				} 
				else {
					mybutton.style.display = "none";
				}
			}

			// When the user clicks on the button, scroll to the top of the document
			function topFunction() {
			document.body.scrollTop = 0;
			document.documentElement.scrollTop = 0;
			}
		</script>

		<style>
			body{
				background-image: url('sitepics/home_background1.png');
				background-attachment: fixed;
				background-position: center;
			}

			@font-face {
				font-family: 'newfont';
				src: url(fonts/Comfortaa-Bold.ttf);
			}
		</style>

	</head>

	<body>

		<section class="background">

			<div class="container">
				<div class="row">
					<div class="col-sm-3">
						<div class="side-panel">
							<div class="left-sidebar">
								<h2>Brand Categories</h2>
								<div class="panel-group" id="accordion">
									<div class="panel panel-default">
										<div class="panel-heading">
											<h4 class="panel-title">
											<a  data-toggle="collapse" data-parent="#accordion" href="#collapse1">Grassroot</a>
											<a data-toggle="collapse" data-parent="#accordion" href="#collapse1"><i class="fa fa-plus pull-right"></i></a>
											</h4>
										</div>
										<div id="collapse1" class="panel-collapse collapse in">
											<div class="panel-body">
												<ul>
													<li><a href="makeitvisible/showb1.php">Clothing</a></li>
													<li>About</li>
												</ul>
											</div>
										</div>
									</div>
									<div class="panel panel-default">
										<div class="panel-heading">
											<h4 class="panel-title">
											<a data-toggle="collapse" data-parent="#accordion" href="#collapse2">Nicobar</a>
											<a data-toggle="collapse" data-parent="#accordion" href="#collapse2"><i class="fa fa-plus pull-right"></i></a>
											</h4>
										</div>
										<div id="collapse2" class="panel-collapse collapse">
											<div class="panel-body">
												<ul>
													<li><a href="makeitvisible/showb2.php">Clothing</a></li>
													<li>About</li>
												</ul>
											</div>
										</div>
									</div>
									<div class="panel panel-default">
										<div class="panel-heading">
											<h4 class="panel-title">
											<a data-toggle="collapse" data-parent="#accordion" href="#collapse3">No Nasties</a>
											<a data-toggle="collapse" data-parent="#accordion" href="#collapse3"><i class="fa fa-plus pull-right"></i></a>
											</h4>
										</div>
										<div id="collapse3" class="panel-collapse collapse">
											<div class="panel-body">
												<ul>
													<li><a href="makeitvisible/showb4.php">Clothing</a></li>
													<li>About</li>
												</ul>
											</div>
										</div>
									</div>
									<div class="panel panel-default">
										<div class="panel-heading">
											<h4 class="panel-title">
											<a  data-toggle="collapse" data-parent="#accordion" href="#collapse4">Okhai</a>
											<a data-toggle="collapse" data-parent="#accordion" href="#collapse4"><i class="fa fa-plus pull-right"></i></a>
											</h4>
										</div>
										<div id="collapse4" class="panel-collapse collapse">
											<div class="panel-body">
												<ul>
													<li><a href="makeitvisible/showb4.php">Clothing</a></li>
													<li>About</li>
												</ul>
											</div>
										</div>
									</div>
									<div class="panel panel-default">
										<div class="panel-heading">
											<h4 class="panel-title">
											<a data-toggle="collapse" data-parent="#accordion" href="#collapse5">Oshida</a>
											<a data-toggle="collapse" data-parent="#accordion" href="#collapse5"><i class="fa fa-plus pull-right"></i></a>
											</h4>
										</div>
										<div id="collapse5" class="panel-collapse collapse">
											<div class="panel-body">
												<ul>
													<li><a href="makeitvisible/showb5.php">Clothing</a></li>
													<li>About</li>
												</ul>
											</div>
										</div>
									</div>
									<div class="panel panel-default">
										<div class="panel-heading">
											<h4 class="panel-title">
											<a data-toggle="collapse" data-parent="#accordion" href="#collapse6">Pemmaraju</a>
											<a data-toggle="collapse" data-parent="#accordion" href="#collapse6"><i class="fa fa-plus pull-right"></i></a>
											</h4>
										</div>
										<div id="collapse6" class="panel-collapse collapse">
											<div class="panel-body">
												<ul>
													<li><a href="makeitvisible/showb6.php">Clothing</a></li>
													<li>About</li>
												</ul>
											</div>
										</div>
									</div>
									<div class="panel panel-default">
										<div class="panel-heading">
											<h4 class="panel-title">
											<a data-toggle="collapse" data-parent="#accordion" href="#collapse7">Sui</a>
											<a data-toggle="collapse" data-parent="#accordion" href="#collapse7"><i class="fa fa-plus pull-right"></i></a>
											</h4>
										</div>
										<div id="collapse7" class="panel-collapse collapse">
											<div class="panel-body">
												<ul>
													<li><a href="makeitvisible/showb7.php">Clothing</a></li>
													<li>About</li>
												</ul>
											</div>
										</div>
									</div>
									<div class="panel panel-default">
										<div class="panel-heading">
											<h4 class="panel-title">
											<a data-toggle="collapse" data-parent="#accordion" href="#collapse8" >Terra Tribe</a>
											<a data-toggle="collapse" data-parent="#accordion" href="#collapse8"><i class="fa fa-plus pull-right"></i></a>
											</h4>
										</div>
										<div id="collapse8" class="panel-collapse collapse">
											<div class="panel-body">
												<ul>
													<li><a href="makeitvisible/showb8.php">Clothing</a></li>
													<li>About</li>
												</ul>
											</div>
										</div>
									</div>
								</div> 
							</div>
						</div>
					</div>

					<div class="col-sm-9 products">
						<div class="clothing-options">
							<h2 class="title text-center">Sustainable clothing options</h2>

							<br/>

							<?php
								$query = "Select * from store_img order by pid";
								$result = mysqli_query($con,$query) or die(mysql_error());
								if(mysqli_num_rows($result)>0){ 
									while($row = mysqli_fetch_array($result)){
							?>

										<div class="col-sm-4">
											<div class="product-image-wrapper center">
												<div class="single-products">
													<div class="productinfo text-center">
														<a href="item_view_auth.php?productid=<?php echo $row['pid'];?>" target="new window">
															<img class="img-responsive" src="<?php echo $row["dir"];?>" alt="<?php echo $row['product_name'];?>"/>
														</a>
														<h4><?php echo $row["product_name"]; ?></h4>
														<p><?php echo $row["brand"]; ?></p>
														<h4>₹<?php echo $row["price"]; ?></h4>
														</a>
													</div>
												</div>
												<div class="choose">
													<ul class="nav nav-pills nav-justified">
														<li><a href="insert-in-cart.php?productid=<?php echo $row['pid'];?>"><i class="fa fa-shopping-cart"></i>To Cart</a></li>
														<li><a href="cart.php?productid=<?php echo $row['pid'];?>"><i class="fa fa-sign-out"></i>Checkout</a></li>
													</ul>
												</div>
											</div>
										</div>
							<?php
									}
								}
							?>

						</div>
					</div>

					

				</div>
			</div>

		</section>

		<?php
			include "footer.html";
		?>

	</body>
</html>